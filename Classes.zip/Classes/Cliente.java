package Classes;

public class Cliente {
    private int idCliente;
    private String no_Cliente;
    private String cpf_Cliente;
    private String email_Cliente;
    private String tel_Cliente;
    private String end_Cliente;
    private String sexo_Cliente;
    private String senha_Cliente;


    public Cliente(int idCliente, String no_Cliente, String cpf_Cliente, String email_Cliente, String tel_Cliente,
            String end_Cliente, String sexo_Cliente, String senha_Cliente) {
        this.idCliente = idCliente;
        this.no_Cliente = no_Cliente;
        this.cpf_Cliente = cpf_Cliente;
        this.email_Cliente = email_Cliente;
        this.tel_Cliente = tel_Cliente;
        this.end_Cliente = end_Cliente;
        this.sexo_Cliente = sexo_Cliente;
        this.senha_Cliente=senha_Cliente;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public String getNo_Cliente() {
        return no_Cliente;
    }

    public void setNo_Cliente(String no_Cliente) {
        this.no_Cliente = no_Cliente;
    }

    public String getCpf_Cliente() {
        return cpf_Cliente;
    }

    public void setCpf_Cliente(String cpf_Cliente) {
        this.cpf_Cliente = cpf_Cliente;
    }

    public String getEmail_Cliente() {
        return email_Cliente;
    }

    public void setEmail_Cliente(String email_Cliente) {
        this.email_Cliente = email_Cliente;
    }

    public String getTel_Cliente() {
        return tel_Cliente;
    }

    public void setTel_Cliente(String tel_Cliente) {
        this.tel_Cliente = tel_Cliente;
    }

    public String getEnd_Cliente() {
        return end_Cliente;
    }

    public void setEnd_Cliente(String end_Cliente) {
        this.end_Cliente = end_Cliente;
    }

    public String getSexo_Cliente() {
        return sexo_Cliente;
    }

    public void setSexo_Cliente(String sexo_Cliente) {
        this.sexo_Cliente = sexo_Cliente;
    }

    public String getSenha_Cliente() {
        return senha_Cliente;
    }

    public void setSenha_Cliente(String senha_Cliente) {
        this.senha_Cliente = senha_Cliente;
    }

    
}