package Classes;

public class Funcionario {
    private int id_Funcionario;
    private String no_Funcionario;
    private String cpf_Funcionario;
    private String email_Funcionario;
    private date nasc_Funcionario;
    private String tel_Funcionario;
    private String end_Funcionario;
    private String sexo_Funcionario;
    private double salario;

    public Funcionario(int id_Funcionario, String no_Funcionario, String cpf_Funcionario, String email_Funcionario,
        String tel_Funcionario, String end_Funcionario, String sexo_Funcionario, double salario) {
        
        this.id_Funcionario = id_Funcionario;
        this.no_Funcionario = no_Funcionario;
        this.cpf_Funcionario = cpf_Funcionario;
        this.email_Funcionario = email_Funcionario;
        this.tel_Funcionario = tel_Funcionario;
        this.end_Funcionario = end_Funcionario;
        this.sexo_Funcionario = sexo_Funcionario;
        this.salario = salario;
    }

    public int getId_Funcionario() {
        return id_Funcionario;
    }

    public void setId_Funcionario(int id_Funcionario) {
        this.id_Funcionario = id_Funcionario;
    }

    public String getNo_Funcionario() {
        return no_Funcionario;
    }

    public void setNo_Funcionario(String no_Funcionario) {
        this.no_Funcionario = no_Funcionario;
    }

    public String getCpf_Funcionario() {
        return cpf_Funcionario;
    }

    public void setCpf_Funcionario(String cpf_Funcionario) {
        this.cpf_Funcionario = cpf_Funcionario;
    }

    public String getEmail_Funcionario() {
        return email_Funcionario;
    }

    public void setEmail_Funcionario(String email_Funcionario) {
        this.email_Funcionario = email_Funcionario;
    }

    public String getTel_Funcionario() {
        return tel_Funcionario;
    }

    public void setTel_Funcionario(String tel_Funcionario) {
        this.tel_Funcionario = tel_Funcionario;
    }

    public String getEnd_Funcionario() {
        return end_Funcionario;
    }

    public void setEnd_Funcionario(String end_Funcionario) {
        this.end_Funcionario = end_Funcionario;
    }

    public String getSexo_Funcionario() {
        return sexo_Funcionario;
    }

    public void setSexo_Funcionario(String sexo_Funcionario) {
        this.sexo_Funcionario = sexo_Funcionario;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
}
