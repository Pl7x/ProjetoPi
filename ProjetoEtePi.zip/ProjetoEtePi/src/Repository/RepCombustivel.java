package Repository;

import negocio.Funcionario;
import BD.ConexaoBanco;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import negocio.Combustivel;

public class RepCombustivel {
    private Connection connection;

    public RepCombustivel(Connection connection) {
        this.connection = connection;
    }

    public void salvar(Combustivel combustivel) throws SQLException {
        String sql = "INSERT INTO tb_Combustivel (noCombustivel, capMax, estoqueAtual, precoLitro) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, combustivel.getNoCombustivel());
            stmt.setDouble(2, combustivel.getCapMax());
            stmt.setDouble(3, combustivel.getEstoqueAtual());
            stmt.setDouble(4, combustivel.getPrecoLitro());
            stmt.executeUpdate();
        }
    }

    public List<Combustivel> listarTodos() throws SQLException {
        List<Combustivel> lista = new ArrayList<>();
        String sql = "SELECT * FROM tb_Combustivel";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                lista.add(mapearCombustivel(rs));
            }
        }
        return lista;
    }

    public void atualizar(Combustivel combustivel) throws SQLException {
        String sql = "UPDATE tb_Combustivel SET  capMax = ?, estoqueAtual = ?, precoLitro = ? WHERE idCombustivel = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDouble(1, combustivel.getCapMax());
            stmt.setDouble(2, combustivel.getEstoqueAtual());
            stmt.setDouble(3, combustivel.getPrecoLitro());
            stmt.setInt(4, combustivel.getIdCombustivel());
            stmt.executeUpdate();
        }
    }
        public void deletar(int id) throws SQLException {
        String sql = "DELETE FROM tb_Combustivel WHERE idCombustivel = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    private Combustivel mapearCombustivel(ResultSet rs) throws SQLException {
        return new Combustivel(
            rs.getInt("idCombustivel"),
            rs.getString("noCombustivel"),
            rs.getDouble("capMax"),
            rs.getDouble("estoqueAtual"),
            rs.getDouble("precoLitro")
        );
    }
}
