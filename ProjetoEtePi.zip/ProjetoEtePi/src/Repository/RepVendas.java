package Repository;

import negocio.Funcionario;
import BD.ConexaoBanco;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import negocio.Combustivel;
import negocio.Vendas;

public class RepVendas {
    private Connection connection;

    public RepVendas(Connection connection) {
        this.connection = connection;
    }

    public void inserir(Vendas venda) throws SQLException {
        String sql = "INSERT INTO tb_Compra (id_Fun, id_Combustivel, qntd_Litros, valor_Pago, forma_pagamento, dt_venda) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, venda.getIdFun());
            stmt.setInt(2, venda.getIdCombustivel());
            stmt.setDouble(3, venda.getQntdLitros());
            stmt.setDouble(4, venda.getValorPago());
            stmt.setString(5, venda.getFormaPagamento());
            stmt.setTimestamp(6, venda.getDtVenda());

            stmt.executeUpdate();
            
        }
    }

public List<Vendas> buscarPorIdFuncionario(int idFuncionario) throws SQLException {
    List<Vendas> lista = new ArrayList<>();
    String sql = "SELECT * FROM tb_Compra WHERE id_Fun = ? ORDER BY dt_venda DESC";
    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setInt(1, idFuncionario);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            lista.add(mapearVenda(rs));
        }
    }
    return lista;
}


    public List<Vendas> listarTodos() throws SQLException {
        List<Vendas> lista = new ArrayList<>();
        String sql = "SELECT * FROM tb_Compra ORDER BY dt_venda DESC";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                lista.add(mapearVenda(rs));
            }
        }
        return lista;
    }


    private Vendas mapearVenda(ResultSet rs) throws SQLException {
        return new Vendas(
            rs.getInt("id_Compra"),
            rs.getInt("id_Fun"),
            rs.getInt("id_Combustivel"),
            rs.getDouble("qntd_Litros"),
            rs.getDouble("valor_Pago"),
            rs.getString("forma_pagamento"),
            rs.getTimestamp("dt_venda")
        );
    }
}
