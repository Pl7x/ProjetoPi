package Repository;

import negocio.Funcionario;
import BD.ConexaoBanco;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class RepFuncionario {

    public boolean inserir(Funcionario funcionario) throws SQLException {
        Connection con = null;
        PreparedStatement stmt = null;

        String sql = "INSERT INTO tb_Funcionario (no_Fun, cpf_Fun, email_Fun, nasc_Fun, tel_Fun, end_Fun, sexo_Fun, senha_Fun, salario, dt_CF, Status) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, md5(?), ?, ?)";

        try {
            con = ConexaoBanco.conectar();
            con.setAutoCommit(false);

            stmt = con.prepareStatement(sql);
            stmt.setString(1, funcionario.getNome());
            stmt.setString(2, funcionario.getCpf());
            stmt.setString(3, funcionario.getEmail());
            stmt.setDate(4, java.sql.Date.valueOf(funcionario.getNascimento()));
            stmt.setString(5, funcionario.getTelefone());
            stmt.setString(6, funcionario.getEndereco());
            stmt.setString(7, funcionario.getSexo());
            stmt.setString(8, funcionario.getSenha());
            stmt.setDouble(9, funcionario.getSalario());
            stmt.setDate(10, java.sql.Date.valueOf(funcionario.getDataCadastro()));

            stmt.executeUpdate();
            con.commit();

            JOptionPane.showMessageDialog(null, "Funcion�rio salvo com sucesso!");
            return true;

        } catch (SQLException e) {
            if (con != null) con.rollback();
            JOptionPane.showMessageDialog(null, "Erro ao salvar funcion�rio: " + e.getMessage());
            return false;

        } finally {
            if (stmt != null) stmt.close();
            if (con != null) con.close();
        }
    }

    public List<Funcionario> retornar() throws SQLException {
        List<Funcionario> funcionarios = new ArrayList<>();
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        String sql = "SELECT * FROM tb_Funcionario ORDER BY id_Fun DESC";

        try {
            con = ConexaoBanco.conectar();
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);  

            while (rs.next()) {
                Funcionario funcionario = new Funcionario();

                funcionario.setId(rs.getInt("id_Fun"));
                funcionario.setNome(rs.getString("no_Fun"));
                funcionario.setCpf(rs.getString("cpf_Fun"));
                funcionario.setEmail(rs.getString("email_Fun"));
                funcionario.setNascimento(rs.getDate("nasc_Fun").toLocalDate());
                funcionario.setTelefone(rs.getString("tel_Fun"));
                funcionario.setEndereco(rs.getString("end_Fun"));
                funcionario.setSexo(rs.getString("sexo_Fun"));
                funcionario.setSenha(rs.getString("senha_Fun"));
                funcionario.setSalario(rs.getDouble("salario"));
                funcionario.setDataCadastro(rs.getDate("dt_CF").toLocalDate());
                funcionario.setStatus(rs.getBoolean("Status"));  // status ativo/inativo

                funcionarios.add(funcionario);
            }

        } catch (SQLException e) {
            return null;
        } 
        return funcionarios;
    }

    public Funcionario achar(String cpf_fun) throws SQLException {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Funcionario funcionario = null;

        String sql = "SELECT * FROM tb_Funcionario WHERE cpf_Fun = ?";

        try {
            con = ConexaoBanco.conectar();
            stmt = con.prepareStatement(sql);
            stmt.setString(1, cpf_fun);
            rs = stmt.executeQuery();

            if (rs.next()) {
                funcionario = new Funcionario();

                funcionario.setId(rs.getInt("id_Fun"));
                funcionario.setNome(rs.getString("no_Fun"));
                funcionario.setCpf(rs.getString("cpf_Fun"));
                funcionario.setEmail(rs.getString("email_Fun"));
                funcionario.setNascimento(rs.getDate("nasc_Fun").toLocalDate());
                funcionario.setTelefone(rs.getString("tel_Fun"));
                funcionario.setEndereco(rs.getString("end_Fun"));
                funcionario.setSexo(rs.getString("sexo_Fun"));
                funcionario.setSenha(rs.getString("senha_Fun"));
                funcionario.setSalario(rs.getDouble("salario"));
                funcionario.setDataCadastro(rs.getDate("dt_CF").toLocalDate());
                funcionario.setStatus(rs.getBoolean("Status"));
            }

        } catch (SQLException e) {
            return null;
        }
        return funcionario;
    }

    public boolean alterar(Funcionario funcionario) throws SQLException {
        Connection con = null;
        PreparedStatement stmt = null;

        String sql = "UPDATE tb_Funcionario SET email_Fun = ?, tel_Fun = ?, end_Fun = ?, Status = ? WHERE id_Fun = ?";

        try {
            con = ConexaoBanco.conectar();
            stmt = con.prepareStatement(sql);
            stmt.setString(1, funcionario.getEmail());
            stmt.setString(2, funcionario.getTelefone());
            stmt.setString(3, funcionario.getEndereco());
            stmt.setBoolean(4, funcionario.getStatus());
            stmt.setInt(5, funcionario.getId());

            int rowsUpdated = stmt.executeUpdate();

            return rowsUpdated > 0;

        } catch (SQLException e) {
            return false;
        } finally {
            if (stmt != null) stmt.close();
            if (con != null) con.close();
        }
    }
   public int login(String cpf, String senha) throws SQLException {
    Connection con = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    int ret = 0;

    String sql = "SELECT id_Fun FROM tb_Funcionario WHERE cpf_Fun = ? AND senha_Fun = md5(?) AND Status = true";

    try {
        con = ConexaoBanco.conectar();
        stmt = con.prepareStatement(sql);
        stmt.setString(1, cpf);
        stmt.setString(2, senha);

        rs = stmt.executeQuery();

        while (rs.next()) {
            ret = rs.getInt("total"); 
        } 
    } catch (SQLException e) {
        e.printStackTrace();
        ret = 0;
    } finally {
        if (rs != null) rs.close();
        if (stmt != null) stmt.close();
        if (con != null) con.close();
    }

    return ret;
}

}
   