package negocio;
import java.sql.Timestamp;

public class Vendas {
    private int idCompra;
    private int idFun;
    private int idCombustivel;
    private double qntdLitros;
    private double valorPago;
    private String formaPagamento;
    private Timestamp dtVenda;

    public Vendas(int idCompra, int idFun, int idCombustivel, double qntdLitros, double valorPago, String formaPagamento, Timestamp dtVenda) {
        this.idCompra = idCompra;
        this.idFun = idFun;
        this.idCombustivel = idCombustivel;
        this.qntdLitros = qntdLitros;
        this.valorPago = valorPago;
        this.formaPagamento = formaPagamento;
        this.dtVenda = dtVenda;
    }

    public int getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }

    public int getIdFun() {
        return idFun;
    }

    public void setIdFun(int idFun) {
        this.idFun = idFun;
    }

    public int getIdCombustivel() {
        return idCombustivel;
    }

    public void setIdCombustivel(int idCombustivel) {
        this.idCombustivel = idCombustivel;
    }

    public double getQntdLitros() {
        return qntdLitros;
    }

    public void setQntdLitros(double qntdLitros) {
        this.qntdLitros = qntdLitros;
    }

    public double getValorPago() {
        return valorPago;
    }

    public void setValorPago(double valorPago) {
        this.valorPago = valorPago;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public Timestamp getDtVenda() {
        return dtVenda;
    }

    public void setDtVenda(Timestamp dtVenda) {
        this.dtVenda = dtVenda;
    }
}
