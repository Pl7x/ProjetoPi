package negocio;

import java.time.LocalDate;

public class Funcionario {
    private int id;
    private String nome;
    private String cpf;
    private String cargo;
    private LocalDate nascimento;
    private String telefone;
    private String endereco;
    private String sexo;
    private String senha;
    private double salario;
    private LocalDate dataCadastro;
    private boolean status;

    public Funcionario() {
        this.status = true;
    }

    public Funcionario(int id, String nome, String cpf, String cargo, LocalDate nascimento, String telefone,
                       String endereco, String sexo, String senha, double salario, LocalDate dataCadastro, boolean status) {
        this.id = id;
        this.nome = nome;
        this.cpf = cpf;
        this.cargo = cargo;
        this.nascimento = nascimento;
        this.telefone = telefone;
        this.endereco = endereco;
        this.sexo = sexo;
        this.senha = senha;
        this.salario = salario;
        this.dataCadastro = dataCadastro;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String email) {
        this.cargo = cargo;
    }

    public LocalDate getNascimento() {
        return nascimento;
    }

    public void setNascimento(LocalDate nascimento) {
        this.nascimento = nascimento;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public LocalDate getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(LocalDate dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
