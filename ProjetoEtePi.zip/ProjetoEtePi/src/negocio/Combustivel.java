package negocio;

public class Combustivel {
    private int idCombustivel;
    private String noCombustivel;
    private double capMax;
    private double estoqueAtual;
    private double precoLitro;

    public Combustivel(int idCombustivel, String noCombustivel, double capMax, double estoqueAtual, double precoLitro) {
        this.idCombustivel = idCombustivel;
        this.noCombustivel = noCombustivel;
        this.capMax = capMax;
        this.estoqueAtual = estoqueAtual;
        this.precoLitro = precoLitro;
    }

    public int getIdCombustivel() {
        return idCombustivel;
    }

    public void setIdCombustivel(int idCombustivel) {
        this.idCombustivel = idCombustivel;
    }

    public String getNoCombustivel() {
        return noCombustivel;
    }

    public void setNoCombustivel(String noCombustivel) {
        this.noCombustivel = noCombustivel;
    }

    public double getCapMax() {
        return capMax;
    }

    public void setCapMax(double capMax) {
        this.capMax = capMax;
    }

    public double getEstoqueAtual() {
        return estoqueAtual;
    }

    public void setEstoqueAtual(double estoqueAtual) {
        this.estoqueAtual = estoqueAtual;
    }

    public double getPrecoLitro() {
        return precoLitro;
    }

    public void setPrecoLitro(double precoLitro) {
        this.precoLitro = precoLitro;
    }
}
