package BD;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TesteConexao {
    public static void main(String[] args) {
        try (Connection conexao = ConexaoBanco.conectar()) {
            if (conexao != null && !conexao.isClosed()) {
                System.out.println("Conex?o com o banco estabelecida com sucesso!");

                String sql = "SELECT 1";

                
                try (PreparedStatement stmt = conexao.prepareStatement(sql);
                     ResultSet rs = stmt.executeQuery()) {

                    if (rs.next()) {
                        System.out.println("Consulta executada com sucesso! Resultado: " + rs.getInt(1));
                    } else {
                        System.out.println("Consulta executada, mas sem resultados.");
                    }

                } catch (SQLException e) {
                    System.err.println("Erro ao executar a consulta: " + e.getMessage());
                }

            } else {
                System.out.println("A conex?o n?o foi estabelecida.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao conectar com o banco: " + e.getMessage());
        }
    }
}
